<?php
$id = $_GET['item'];
switch($id) {
	
	//1st from the left
	case '1' :
	
	echo '
			<img class="con_borderImage" src="images/light/timeline_content/1w.jpg" alt=""/>
			<div class="timeline_open_content">
			<h2 class="no-marg-top">LOREM IPSUM DOLOR</h2>
			Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. <br /><br />
			
			Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
			</div>';
	break;
	
	// 2nd item
	case '2' :
	
	echo '
			<img class="con_borderImage" src="images/light/timeline_content/2w.jpg" alt=""/>
			<div class="timeline_open_content">
			<h2 class="no-marg-top">LOREM IPSUM DOLOR</h2>
			Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. <br /><br />
			
			Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
			</div>';
	break;
	
	// 3rd item
	case '3' :
	
	echo '
			<img class="con_borderImage" src="images/light/timeline_content/3w.jpg" alt=""/>
			<div class="timeline_open_content">
			<h2 class="no-marg-top">LOREM IPSUM DOLOR</h2>
			Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. <br /><br />
			
			Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
			</div>';
	break;
	
	// 4th item
	case '4' :
	
	echo '
			<img class="con_borderImage" src="images/light/timeline_content/4w.jpg" alt=""/>
			<div class="timeline_open_content">
			<h2 class="no-marg-top">LOREM IPSUM DOLOR</h2>
			Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. <br /><br />
			
			Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
			</div>';
	break;
	
	// 5th item
	case '5' :
	
	echo '
			<img class="con_borderImage" src="images/light/timeline_content/5w.jpg" alt=""/>
			<div class="timeline_open_content">
			<h2 class="no-marg-top">LOREM IPSUM DOLOR</h2>
			Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. <br /><br />
			
			Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
			</div>';
	break;
	
	// 6th item
	case '6' :
	
	echo '<img class="con_borderImage" src="images/light/timeline_content/6w.jpg" alt=""/>
			<div class="timeline_open_content">
			<h2 class="no-marg-top">LOREM IPSUM DOLOR</h2>
			Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. <br /><br />
			
			Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
			</div>';
	break;
	
	// 7th item
	case '7' :
	
	echo '
			<img class="con_borderImage" src="images/light/timeline_content/7w.jpg" alt=""/>
			<div class="timeline_open_content">
			<h2 class="no-marg-top">LOREM IPSUM DOLOR</h2>
			Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. <br /><br />
			
			Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
			</div>';
	break;
	
	// 8th item
	case '8' :
	
	echo '
			<img class="con_borderImage" src="images/light/timeline_content/8w.jpg" alt=""/>
			<div class="timeline_open_content">
			<h2 class="no-marg-top">LOREM IPSUM DOLOR</h2>
			Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. <br /><br />
			
			Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
			</div>';
	break;
	
	// 9th item
	case '9' :
	
	echo '
			<img class="con_borderImage" src="images/light/timeline_content/9w.jpg" alt=""/>
			<div class="timeline_open_content">
			<h2 class="no-marg-top">LOREM IPSUM DOLOR</h2>
			Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. <br /><br />
			
			Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
			</div>';
	break;
	
	// 10th item
	case '10' :
	
	echo '
			<img class="con_borderImage" src="images/light/timeline_content/10w.jpg" alt=""/>
			<div class="timeline_open_content">
			<h2 class="no-marg-top">LOREM IPSUM DOLOR</h2>
			Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. <br /><br />
			
			Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
			</div>';
	break;
	
	// 11th item
	case '11' :
	
	echo '
			<img class="con_borderImage" src="images/light/timeline_content/11w.jpg" alt=""/>
			<div class="timeline_open_content">
			<h2 class="no-marg-top">LOREM IPSUM DOLOR</h2>
			Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. <br /><br />
			
			Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
			</div>';
	break;
	
	// 12th item
	case '12' :
	
	echo '
			<img class="con_borderImage" src="images/light/timeline_content/12w.jpg" alt=""/>
			<div class="timeline_open_content">
			<h2 class="no-marg-top">LOREM IPSUM DOLOR</h2>
			Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. <br /><br />
			
			Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
			</div>';
	break;
	
	
	
	
	
	
	
	
	
}
?>